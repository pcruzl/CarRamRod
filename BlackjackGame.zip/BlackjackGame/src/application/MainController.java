package application;

import java.io.IOException;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class MainController implements EventHandler {

	@FXML private TextArea myTextArea;
	@FXML private TextField myTextField;


	@FXML public void handle(Event event) {
		


		try {
			disney.loadMovieInfo("data/movies.csv");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		if (myTextField.getText().isEmpty()) {
			myTextArea.setText("No results");
		}
		else {
			myTextArea.setText(disney.getMoviesByName(myTextField.getText()));
		}
	}

}
