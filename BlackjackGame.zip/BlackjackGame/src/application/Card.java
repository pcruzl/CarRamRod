package application;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Card {
private int suit;
private int value;
private String suitName;
private String cardName;


//The card class is made so that two ints designate the card for example (0,1)= ace of spades
//This will help when we have a bunch of gif files to link to them and allows a for loop to make a deck.
public Card(int s, int v) {
	this.suit=s;
	this.value=v;
	this.suitName="";
	this.cardName="";
}


//Notice that suits are 0-3 and values are 1-13.  The values start at 1 so I don't have to shift them all when adding
//A total value for the cards.  
//The result of make name is a string like "Ace of Spades"
public String makeName(int s, int v) {
	int dasuit=s;
	int davalue=v;
	String result="";
	
	switch (dasuit) {
	case 0: suitName="Spades.png";
	break;
	case 1: suitName="Clubs.png";
	break;
	case 2: suitName="Hearts.png";
	break;
	case 3: suitName="Diamonds.png";
	break;
	default: suitName="Error";
	}
	switch(davalue) {
	case 1: cardName="Ace_";
	break;
	case 2: cardName="Duece_";
	break;
	case 3: cardName="Three_";
	break;
	case 4: cardName="Four_";
	break;
	case 5: cardName="Five_";
	break;
	case 6: cardName="Six_";
	break;
	case 7: cardName="Seven_";
	break;
	case 8: cardName="Eight_";
	break;
	case 9: cardName="Nine_";
	break;
	case 10: cardName="Ten_";
	break;
	case 11: cardName="Jack_";
	break;
	case 12: cardName="Queen_";
	break;
	case 13: cardName="King_";
	break;
	default: cardName="Error";
	}
	result=cardName + "of_" + suitName+"\n";
	
	return result;
}



public int getSuit() {
	return suit;
}


public void setSuit(int suit) {
	this.suit = suit;
}


public String getSuitName() {
	return suitName;
}


public void setSuitName(String suitName) {
	this.suitName = suitName;
}


public String getCardName() {
	return cardName;
}


public void setCardName(String cardName) {
	this.cardName = cardName;
}



public void loadMovieInfo(String csvFile) throws IOException{

	BufferedImage img = null;
	try {
	    img = ImageIO.read(new File(makeName(getValue(),getSuit())));
	} catch (IOException e) {
	}


}


	
//for totaling the cards in blackjack
public int getValue() {
	return value;
}

//setValue will never be used.
public void setValue(int value) {
	this.value = value;
}

//ToString just calls makeName() method.
public String toString() {
String result="";
result = makeName(suit,value);
return result;
}
}
